import { Mongo } from 'meteor/mongo';

export const Tarefa = new Mongo.Collection('tarefa');


